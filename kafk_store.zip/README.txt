# متجر كافk
ملف الموقع الرئيسي هو `index.html`.
يمكن نشره مجاناً باستخدام GitHub Pages أو Netlify.
